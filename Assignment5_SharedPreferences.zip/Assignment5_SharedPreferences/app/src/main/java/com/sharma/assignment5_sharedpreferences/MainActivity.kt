package com.sharma.assignment5_sharedpreferences

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var textViewSavedName: TextView
    private lateinit var btnSave: Button
    private lateinit var btnLoad: Button

    private val PREF_NAME = "MyPrefs"
    private val KEY_NAME = "saved_name"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.editTextName)
        textViewSavedName = findViewById(R.id.textViewSavedName)
        btnSave = findViewById(R.id.btnSave)
        btnLoad = findViewById(R.id.btnLoad)

        btnSave.setOnClickListener {
            saveData()
        }

        btnLoad.setOnClickListener {
            loadData()
        }

        loadData()
    }


    private fun saveData() {
        val sharedPreferences: SharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        val editor: SharedPreferences.Editor = sharedPreferences.edit()

        editor.putString(KEY_NAME, editTextName.text.toString())

        editor.apply()

        Toast.makeText(this, "Name saved successfully!", Toast.LENGTH_SHORT).show()
    }

    private fun loadData() {
        val sharedPreferences: SharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        val savedName = sharedPreferences.getString(KEY_NAME, "")

        textViewSavedName.text = savedName

        if (!savedName.isNullOrEmpty()) {
            Toast.makeText(this, "Name loaded!", Toast.LENGTH_SHORT).show()
        }
    }
}