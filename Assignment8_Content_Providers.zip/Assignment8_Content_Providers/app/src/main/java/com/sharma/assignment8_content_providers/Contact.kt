package com.sharma.assignment8_content_providers

data class Contact(
    val name: String,
    val homePhone: String,
    val workPhone: String,
    val photoUri: String?
)

