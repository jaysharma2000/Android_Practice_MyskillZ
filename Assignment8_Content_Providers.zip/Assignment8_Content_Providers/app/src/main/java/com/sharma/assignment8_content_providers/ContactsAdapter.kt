package com.sharma.assignment8_content_providers

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class ContactsAdapter(context: Context, contacts: List<Contact>) :
    ArrayAdapter<Contact>(context, 0, contacts) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val contact = getItem(position)!!

        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.list_item_contact, parent, false)

        val tvName = view.findViewById<TextView>(R.id.contactName)
        val tvHomePhone = view.findViewById<TextView>(R.id.contactHomePhone)
        val tvWorkPhone = view.findViewById<TextView>(R.id.contactWorkPhone)
        val ivPhoto = view.findViewById<ImageView>(R.id.contactPhoto)

        tvName.text = contact.name
        tvHomePhone.text = "Home: ${contact.homePhone.ifEmpty { "N/A" }}"
        tvWorkPhone.text = "Work: ${contact.workPhone.ifEmpty { "N/A" }}"

        if (contact.photoUri != null) {
            ivPhoto.setImageURI(Uri.parse(contact.photoUri))
        } else {
            ivPhoto.setImageResource(R.mipmap.ic_launcher_round)
        }

        return view
    }
}