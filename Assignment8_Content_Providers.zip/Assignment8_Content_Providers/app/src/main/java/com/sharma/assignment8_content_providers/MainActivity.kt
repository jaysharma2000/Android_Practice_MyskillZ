package com.sharma.assignment8_content_providers

import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var contactsListView: ListView
    private val READ_CONTACTS_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        contactsListView = findViewById(R.id.contactsListView)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.READ_CONTACTS), READ_CONTACTS_PERMISSION_CODE)
        } else {
            loadContacts()
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == READ_CONTACTS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadContacts()
            } else {
                Toast.makeText(this, "Permission denied. Cannot load contacts.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadContacts() {
        val contactsList = mutableListOf<Contact>()

        val projection = arrayOf(
            ContactsContract.Contacts._ID,
            ContactsContract.Contacts.DISPLAY_NAME,
            ContactsContract.Contacts.PHOTO_URI
        )

        val cursor = contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            projection,
            null,
            null,
            ContactsContract.Contacts.DISPLAY_NAME + " ASC"
        )

        cursor?.use {
            val idColumn = it.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
            val nameColumn = it.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)
            val photoUriColumn = it.getColumnIndexOrThrow(ContactsContract.Contacts.PHOTO_URI)

            while (it.moveToNext()) {
                val contactId = it.getString(idColumn)
                val name = it.getString(nameColumn)
                val photoUri = it.getString(photoUriColumn)

                var homePhone = ""
                var workPhone = ""
                var mobilePhone = ""

                val phoneCursor = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                    arrayOf(contactId),
                    null
                )

                phoneCursor?.use { pc ->
                    val numberColumn = pc.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    val typeColumn = pc.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)

                    while (pc.moveToNext()) {
                        val number = pc.getString(numberColumn)
                        when (pc.getInt(typeColumn)) {
                            ContactsContract.CommonDataKinds.Phone.TYPE_HOME -> homePhone = number
                            ContactsContract.CommonDataKinds.Phone.TYPE_WORK -> workPhone = number
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE -> mobilePhone = number
                        }
                    }
                }
                if (homePhone.isEmpty() && mobilePhone.isNotEmpty()) {
                    homePhone = mobilePhone
                }

                contactsList.add(Contact(name, homePhone, workPhone, photoUri))
            }
        }

        val adapter = ContactsAdapter(this, contactsList)
        contactsListView.adapter = adapter
    }

}