package com.sharma.assignment7_broadcast_receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootCompletedReceiver : BroadcastReceiver() {
    private val TAG = "BootReceiver"
    override fun onReceive(context: Context, intent: Intent) {
        Log.d(TAG, "Boot completed event received!")

        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.d(TAG, "Action is BOOT_COMPLETED, preparing to launch activity.")

            val launchIntent = Intent(context, MainActivity::class.java)

            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            context.startActivity(launchIntent)
        }
    }
}

