package com.sharma.assignment4_activitya

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ActivityA2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_a2)

        val btnLaunchB1 = findViewById<Button>(R.id.btn_launch_b1)
        btnLaunchB1.setOnClickListener {

            val intent = Intent()

            intent.action = "com.sharma.assignment4_activityb.LAUNCH_B1"

            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "Application B not found!", Toast.LENGTH_SHORT).show()
                Log.e("ActivityA2", "No activity found to handle action: com.example.applicationb.LAUNCH_B1")
            }
        }
    }
}
