 package com.sharma.assignment4_activitya

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

 class ActivityA1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_a1)

        val btnLaunchA2 = findViewById<Button>(R.id.btn_launch_a2)
        btnLaunchA2.setOnClickListener {
            val intent = Intent(this, ActivityA2::class.java)
            startActivity(intent)
        }
    }
}