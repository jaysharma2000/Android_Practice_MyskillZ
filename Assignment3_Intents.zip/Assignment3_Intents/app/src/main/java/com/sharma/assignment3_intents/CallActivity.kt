package com.sharma.assignment3_intents

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CallActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_call)

        val intent = intent
        val number = intent.getStringExtra("number")

        val textViewNumber = findViewById<TextView>(R.id.textViewNumber)
        val btnCall = findViewById<Button>(R.id.btnCall)
        textViewNumber.text = number

        btnCall.setOnClickListener {
            Toast.makeText(applicationContext, "Calling", Toast.LENGTH_SHORT).show()
        }
    }
}