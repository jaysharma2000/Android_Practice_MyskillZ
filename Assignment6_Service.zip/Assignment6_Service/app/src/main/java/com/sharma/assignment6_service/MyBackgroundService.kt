package com.sharma.assignment6_service

import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.widget.Toast

class MyBackgroundService : android.app.Service()  {

    private val TAG = "MyBackgroundService"
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var runnable: Runnable

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service onCreate")
        Toast.makeText(this, "Service Created", Toast.LENGTH_SHORT).show()

        runnable = Runnable {
            Log.d(TAG, "Service is running... Log message from Service.")
            handler.postDelayed(runnable, 2000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Service onStartCommand")
        Toast.makeText(this, "Service Started", Toast.LENGTH_SHORT).show()

        handler.post(runnable)

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Service onDestroy")
        Toast.makeText(this, "Service Stopped", Toast.LENGTH_SHORT).show()

        handler.removeCallbacks(runnable)
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }
}