package com.sharma.assignment2_ui_events

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        Toast.makeText(this, "Application Launched!", Toast.LENGTH_SHORT).show()

        val btnShowToast = findViewById<Button>(R.id.btnShowToast)
        val btnNavigate = findViewById<Button>(R.id.btnNavigate)

        btnShowToast.setOnClickListener {
            Toast.makeText(this, "Button is clicked", Toast.LENGTH_LONG).show()
        }

        btnNavigate.setOnClickListener {
            val intent = Intent(this, SplitScreenActivity::class.java)
            startActivity(intent)
        }
    }
}